from tkinter import *

from GuiUtilities.ListBoxUtility import ListBoxTest
from GuiUtilities.MenusAndPopupMenus import addMenusUsinglist, diableMenus


def  disableStringListBarOption(lbtmyMenuBAr,menuOptionName ) :
     print(menuOptionName)
     lbtmyMenuBAr.entryconfig(menuOptionName, state=DISABLED)
def moveFields(mylistBox,mylistBoxDest) :
    try  :
         selitem = mylistBox.get(ACTIVE)
         idx = mylistBox.curselection()
         mylistBox.delete(idx, idx)
         mylistBoxDest.insert("end", selitem)
    except    :
          return
def newListBoxTrigger(label,*args) :
    print(args)
    StringlistBox     = args[0][0][0]
    numericlistBoxDest = args[0][0][1]
    dateLsitBoxDest = args[0][0][2]
    # selitem = mylistBox.get(ACTIVE)
    # print(mylistBoxDest,mylistBox.get(ACTIVE) )
    if (label == "move to Numeric" )  :
         moveFields(StringlistBox, numericlistBoxDest)
    elif (label == "move Back to GeneralFields" )  :
        moveFields( numericlistBoxDest,StringlistBox)
        moveFields(dateLsitBoxDest, StringlistBox)
    elif (label == "move to Date Field" )  :
        moveFields(StringlistBox, dateLsitBoxDest)
    return
if __name__ == "__main__" :
    root= Tk()
    root.resizable(0, 0)
    myFrameTop = Frame(height=14,width=50,bd=5,padx=9, pady=9)
    myFrameTop.pack(side=TOP)

    w = Label(myFrameTop, text="Re Arrange Fileds to Numeric and DAte",font=(None, 15)).pack(side=TOP)

    myFrameTop = Frame(height=14, width=50, bd=5, padx=9, pady=9)
    # w = Label(myFrameTop, text = " ", font = (None, 15)).pack(side = LEFT)
    Button(myFrameTop,text="     QUIT      ").pack(side=LEFT)
    myFrameTop.pack(side=BOTTOM)
    Label(root, text = "     ").pack(side = LEFT)

    myFrame = Frame(height=14, bd=5, width=10, padx=2, pady=2, relief=SUNKEN)
    w = Label(myFrame, text="String Field").pack(side=TOP)
    lbt = ListBoxTest(myFrame, [1, 2, 3, 4, 5, 6, 7, 8, 9,10], [1, 2, 3, 4, 5, 6, 7, 8, 9.10])
    lbt.list_box_1.pack(side=BOTTOM)
    myFrame.pack(side=LEFT)
    myFrame = Frame(height = 14, bd = 5, width = 10, )

    # Button(myFrame,text="Move to \n Numeric --->").pack(side=TOP)
    # # Label(myFrame,text= "  ").pack(side=TOP)
    # Label(myFrame, text = "  ").pack(side = TOP)
    #
    # Button(myFrame, text = "Move Back\n <-------To String ").pack(side = TOP)
    # Label(myFrame, text = "  ").pack(side = TOP)
    #
    #
    # Button(myFrame, text = "Move to \nDate ---->").pack(side = BOTTOM)
    myFrame.pack(side = LEFT)
    myFrame1 = Frame(height=14, bd=5, width=10, padx=2, pady=2, relief=SUNKEN)
    Label(root, text="     ").pack(side=LEFT)
    # Button(root , text="Move TO Numeric").pack(side=TOP)
    # Button(root, text = "Move TO Date").pack(side = TOP)
    w = Label(myFrame1, text="Numeric Field").pack(side=TOP)
    lbtNuemric = ListBoxTest(myFrame1, [])
    lbtNuemric.list_box_1.pack(side=BOTTOM)
    myFrame1.pack(side=LEFT)


    myFrame2 = Frame(height=14, bd=5, width=10, padx=2, pady=2, relief=SUNKEN)
    Label(root, text="     ").pack(side=LEFT)
    w = Label(myFrame2, text="Date Field").pack(side=TOP)
    lbtDate = ListBoxTest(myFrame2, [])
    lbtDate.list_box_1.pack(side=BOTTOM)
    myFrame2.pack(side=LEFT)

    moveBackListpopup = ["move to Numeric" , "move to Date Field" ]

    lbt.list_box_1.bind('<<ListboxSelect>>', func=disableStringListBarOption(lbt.myMenuBAr,8) )

    addMenusUsinglist(lbt.myPopupMenu, moveBackListpopup, newListBoxTrigger, lbt.list_box_1,
                      lbtNuemric.list_box_1,lbtDate.list_box_1)
    moveBackListpopup = ["move Back to GeneralFields"]
    addMenusUsinglist(lbtNuemric.myPopupMenu, moveBackListpopup, newListBoxTrigger, lbt.list_box_1,
                      lbtNuemric.list_box_1, lbtDate.list_box_1)
    addMenusUsinglist(lbtDate.myPopupMenu, moveBackListpopup, newListBoxTrigger, lbt.list_box_1,
                       lbtNuemric.list_box_1,lbtDate.list_box_1)
    Label(root, text = "     ").pack(side = LEFT)
    # w = Label(root, text="    ", font=(None, 25)).pack(side= BOTTOM)
    # myFrameTop = Frame(height=14, width=50, bd=5, padx=9, pady=9)

    # myFrameTop.pack(side=BOTTOM)

    root.mainloop()

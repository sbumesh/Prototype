from tkinter import Tk, Label, W, E, SUNKEN, Frame, N, Button, S

from GuiUtilities.ListBoxUtility import ListBoxTest

root=Tk()




Label(root, text="       ").grid(row= 0,column= 6,sticky=E,columnspan = 3,rowspan = 6)
# Label(root, text="       ").grid(row= 0,column= 1,sticky=E,columnspan = 3,rowspan = 3)
Label(root, text="First").grid(row= 7,column= 3,sticky=E)
lbt = ListBoxTest(root, [1, 2, ], [1, 2, 3, 4, 5, 6, 7, 8, 9.10])
lbt.list_box_1.grid(row=8,column=1,sticky= E,rowspan=3,columnspan=5)

Label(root, text="       ").grid(row= 6,column= 6,sticky=E,columnspan = 3,rowspan = 6)
Label(root, text="First").grid(row= 7,column= 10,sticky=E)
lbt = ListBoxTest(root, [1, 2, ], [1, 2, 3, 4, 5, 6, 7, 8, 9.10])
lbt.list_box_1.grid(row=8,column=10,sticky= S,rowspan=3,columnspan=5)
# myFrame = Frame(root,height=6).grid(row=0,rowspan=5)
Label(root, text="       ").grid(row= 6,column= 16,sticky=W,columnspan = 3,rowspan = 6)
Label(root, text="First").grid(row= 7,column= 25,sticky=E)
lbt = ListBoxTest(root, [1, 2, ], [1, 2, 3, 4, 5, 6, 7, 8, 9.10])
lbt.list_box_1.grid(row=8,column=23,sticky= S,rowspan=3,columnspan=5)


# Label(root, text="F ").grid(row= 14,column=16 ,sticky=N,rowspan= 13)
# Label(myFrame, text="First").grid(row= 4,column=6 ,sticky=E)
# Label(myFrame, text="First").grid(row= 5,column=7 ,sticky=E)
# Label(myFrame, text="First10").grid(row= 10,column= 7,sticky=W+E)
# myFrame.grid(row=15,column = 6 ,rowspan= 20,columnspan = 23,stick=N+S)
# Label(root, text="Secord").grid(row= 0 ,column= 6,  sticky = N+E)
# myFrame = Frame(height=140, bd=5, width=100, padx=2, pady=2, relief=SUNKEN).grid(row=1,column = 6 ,columnspan = 3)
# Label(root, text="Third").grid(row= 0 ,column= 9,  sticky = N+E)
# myFrame = Frame(height=140, bd=5, width=100, padx=2, pady=2, relief=SUNKEN).grid(row=1,column = 9 ,columnspan = 3)
root.mainloop()
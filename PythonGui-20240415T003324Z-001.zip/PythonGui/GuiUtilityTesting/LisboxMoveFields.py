from tkinter import Tk, ACTIVE, Label, Frame, W, SUNKEN, X

from GuiUtilities.ListBoxUtility import ListBoxTest
from GuiUtilities.MenusAndPopupMenus import addMenusUsinglist
def moveFields(mylistBox,mylistBoxDest) :
    selitem = mylistBox.get(ACTIVE)
    idx = mylistBox.curselection()
    mylistBox.delete(idx, idx)
    mylistBoxDest.insert("end", selitem)
def newListBoxTrigger(label,*args) :
    print(args)
    mylistBox     = args[0][0][0]
    mylistBoxDest = args[0][0][1]
    mylistBoxDestDate = args[0][0][2]
    # selitem = mylistBox.get(ACTIVE)
    # print(mylistBoxDest,mylistBox.get(ACTIVE) )
    if (label == "move to Numeric" )  :
         moveFields(mylistBox, mylistBoxDest)
    elif (label == "move Back to GeneralFields" )  :
        moveFields( mylistBoxDest,mylistBox)
    elif (label == "move to Date Field" )  :
        moveFields(mylistBox, mylistBoxDestDate)
    return
if __name__ == '__main__'  :
   root = Tk()
   myFrame = Frame(height=14, bd=2, width= 10, padx=20,pady = 20,relief=SUNKEN)

   w = Label(myFrame, text="String Field").grid(row=0,column = 0)
   myFramenumeric = Frame()



   lbt=ListBoxTest( myFrame, [1,2,3,4,5,6,7,8,9.10]   ,  [1,2,3,4,5,6,7,8,9.10])
   lbt.myMenuBAr.add_separator()
   lbt.myMenuBAr.add_separator()
   lbt.list_box_1.grid(row=1,column=0)
   myFrame.grid(row=0)  #.pack(fill=X, padx=5, pady=5)
   additionalListpopup = [ "move to Numeric" , "move to Date Field", "Move to string Field"]



   lbt12 = ListBoxTest(myFramenumeric, [])
   moveBackListpopup = ["move Back to GeneralFields"  ]


   lbt12.list_box_1.grid(row=0,column=3)

   myFrameDate = Frame(height=14, bd=2, width= 10, padx=20,pady = 20,relief=SUNKEN)
   w1 = Label(myFrameDate, text="Date Fields").grid(row=0, column=0)
   lbtDate = ListBoxTest(myFrameDate, [1])
   moveBackListpopup = ["move Back to GeneralFields"]
   addMenusUsinglist(lbtDate.myMenuBAr, moveBackListpopup, newListBoxTrigger, lbt.list_box_1, lbtDate.list_box_1,lbtDate.list_box_1)
   # addMenusUsinglist(lbt.myMenuBAr, additionalListpopup, newListBoxTrigger, lbt.list_box_1, lbtDate.list_box_1)
   addMenusUsinglist(lbt.myMenuBAr, additionalListpopup, newListBoxTrigger, lbt.list_box_1, lbt12.list_box_1,lbtDate.list_box_1)
   lbtDate.list_box_1.grid(row=0, column=1)
   w1 = Label(myFramenumeric, text="Numeric Fields").grid(row=0, column=2)
   myFramenumeric.grid(row=0, column=3)
   myFrameDate.grid(row=0, column=1)
   root.mainloop()
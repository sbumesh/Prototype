from tkinter import Tk, mainloop, Button, Label, Entry, StringVar

from GuiUtilities.Template.TextBoxUtilityClass import gettextArea12

LARGE_FONT = ("ariel", 20)
rowmax=50
columnMax=40
leftSpace=1
rightSpace=columnMax -3
def addgrids(self):
    for i in range(columnMax):
        self.columnconfigure(i, weight = 1)
    for i in range(rowmax):
        self.rowconfigure(i, weight = 1)
root = Tk()
addgrids(root)
### Title
Label(root, text = "Panda Excel Utility" ,font=LARGE_FONT ).grid(row = 0, sticky = 'w',column = 5  )
####Prompt
Label(root, text = "Numeric Column"  ).grid(row = 2, sticky = 'w',column = leftSpace   )
Label(root, text = "Excel Tab for"  ).grid(row = 3, sticky = 'w',column = leftSpace   )
Label(root, text = "Highlight Metrics"  ).grid(row = 4, sticky = 'w',column = leftSpace   )

# lbt=ListBoxTest( root, ['Min' , 'Max' , 'Avg' , 'Null']   )
# lbt.list_box_1.grid(row=4,column = leftSpace + 4)
Entry( root,width= 100 ).grid(row = 2, sticky = 'w',column = leftSpace+2     )
Entry( root,width= 78).grid(row = 3, sticky = 'w',column = leftSpace + 2  )
v = StringVar()
v.set('min,max,avg')
Entry( root ,textvariable=v ,width= 78).grid(row = 4, sticky = 'w',column = leftSpace + 2  )

### TextBox and Command Line
myText,myMenubar = gettextArea12(root)
root.geometry("1399x880")
myText.grid(row = 15, sticky = 'nswe',column = leftSpace,columnspan = columnMax -4,rowspan=28)
Button(root, text = "Open CSV File").grid(row = 15, sticky = 'nswe',column = columnMax-2,columnspan = 1,rowspan=1)
Button(root, text = "Process File").grid(row = 20, sticky = 'nswe',column = columnMax-2,columnspan = 1,rowspan=1)
Button(root, text = "Exit").grid(row = 22, sticky = 'nswe',column = columnMax-2,columnspan = 1,rowspan=1)
mainloop()
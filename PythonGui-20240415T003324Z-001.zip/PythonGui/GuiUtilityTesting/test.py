import tkinter as tk
from tkinter import ttk

LARGE_FONT = ("ariel", 20) # dont know what you had here

class Main(tk.Tk):
    def __init__(self, *args, **kwargs):

        tk.Tk.__init__(self, *args, **kwargs)
        self.grid_rowconfigure(0, weight=1) # this needed to be added
        self.grid_columnconfigure(0, weight=1) # as did this

        main_container = tk.Frame(self)
        main_container.grid(column=0, row=0, sticky = "nsew")
        main_container.grid_rowconfigure(0, weight = 1)
        main_container.grid_columnconfigure(0, weight = 1)

        menu_bar = tk.Menu(main_container)
        file_menu = tk.Menu(menu_bar, tearoff = 0)
        file_menu.add_command(label = "Save settings") #, command = lambda: popupmsg("Not supported yet!"))
        file_menu.add_separator()
        file_menu.add_command(label = "Exit", command = quit)
        menu_bar.add_cascade(label = "File", menu = file_menu)

        tk.Tk.config(self, menu = menu_bar)

        self.frames = {}

        for fr in (MainPage,):
            frame = fr(main_container, self)
            self.frames[fr] = frame
            frame.grid(row = 0, column = 0, sticky = "nsew")
        self.show_frame(MainPage)

    def show_frame(self, pointer):
        frame = self.frames[pointer]
        frame.tkraise()


class MainPage(tk.Frame):
    def addgrids(self):
        for i in range(19):
           self.columnconfigure(i, weight = 1)
        for i in range(20):
               self.rowconfigure(i, weight = 1)
           # ttk.Button(self, text = "Graphs"+str(i)).grid(row = 1, column = i)
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        # uncommented these lines
        # self.columnconfigure(0, weight = 1)
        # self.rowconfigure(0, weight = 1)
        # self.rowconfigure(1, weight = 1)
        # self.rowconfigure(2, weight = 1)
        # self.rowconfigure(3, weight = 1)
        self.addgrids()
        label = tk.Label(self, text = "Main Page", font = LARGE_FONT)
        # ttk.Button(self, text = "Graphs"  ).grid(row = 0, column = 5)
        # label.grid(row = 0)

        # button1 = ttk.Button(self, text = "Graphs", command = lambda: controller.show_frame(GraphsPage))


        # button1.grid(row = 1, column = 3, sticky = 'nswe')
        ttk.Button(self, text = "Graphs1").grid(row = 1, sticky = 'nswe',column = 15)
        # ttk.Button(self, text = "Graphs2").grid(row = 1, column = 5, sticky = 'nswe')
        # ttk.Button(self, text = "Graphs3").grid(row = 1, column = 18, sticky = 'nswe')
        # self.columnconfigure(4, weight = 1)
        # button1.grid(row = 1, column = 5, sticky = 'nswe')
        # self.columnconfigure(5, weight = 1)
        # self.columnconfigure(6, weight = 1)
        # self.columnconfigure(7, weight = 1)

        self.columnconfigure(94, weight = 1)
        # label.grid(row = 1, column = 77, padx = 10, pady = 10)
        # button1.grid(row = 1, column = 7, sticky = 'nswe')
        button2 = ttk.Button(self, text = "Page 2")
        button2.grid(row = 2, column=15 , sticky = 'nswe',columnspan = 18)

        button3 = ttk.Button(self, text = "Exit", command = quit)
        button3.grid(row = 5, column = 1,sticky = 'nswe',rowspan = 15 ,columnspan= 16)
        ttk.Button(self, text = "Exit", command = quit).grid(row = 5, column = 18,columnspan= 2)
        ttk.Button(self, text = "Exit", command = quit).grid(row = 6, column = 18, columnspan = 2)
        ttk.Button(self, text = "Exit", command = quit).grid(row = 8, column = 18, columnspan = 2)

app = Main()
app.geometry("1380x820")
app.mainloop()
from tkinter import Tk, mainloop, Menu

from GuiUtilities.MenusAndPopupMenus import getMenuBarAndDispaly_0, addMenusUsinglist, alertBox, subMenus_00


def fileMenuTrigger(MenuSelectedTExt="",obj=None) :
    alertBox(message="From File menu " + MenuSelectedTExt)
    return

def dfMenuTrigger(MenuSelectedTExt="",obj=None) :
    alertBox(message="From Data Frame menu : " + MenuSelectedTExt)
    return
def streamingMenuTrigger(MenuSelectedTExt="",obj=None) :
    alertBox(message="From streaming menu : " + MenuSelectedTExt)
    return


def graphFrameMenuTrigger(label,*args ) :#MenuSelectedTExt="",obj=None) :
    # alertBox(message="From graph Frame Menu  : " + label)
    print(args)
    return

def textBoxMenuTrigger(label,*args ) :#MenuSelectedTExt="",obj=None) :
    if (label == "Clear") :
          print(args)
    return
def GraphFrameMenu() :
    graphMenu = getMenuBarAndDispaly_0(MenuBar, "Graph Frame")
    addMenusUsinglist(graphMenu, ['open', 'save', 'quit'], graphFrameMenuTrigger)

    graphSubMenu = subMenus_00(parentMenu=graphMenu, root=root, label="Sub menu1")

    addMenusUsinglist(graphSubMenu, ['open', 'save', 'quit'], graphFrameMenuTrigger,'hello')

    return graphMenu


if __name__ == "__main__":
# if __name__ == "___main__"   :
    root = Tk()
    root.configure(background='sky blue')
    MenuBar = Menu(root)
    FileMenu = getMenuBarAndDispaly_0(MenuBar, "File")
    addMenusUsinglist(FileMenu, ['open' , 'save' , 'quit'] , fileMenuTrigger)

    dataFrameMenu = getMenuBarAndDispaly_0(MenuBar, "Data Frame")
    addMenusUsinglist(dataFrameMenu, ['open' , 'save' , 'quit'] , dfMenuTrigger)

    streamingMenu = getMenuBarAndDispaly_0(MenuBar, "Streaming")
    addMenusUsinglist(streamingMenu, ['open' , 'save' , 'quit'] , streamingMenuTrigger)

    graphMenu = GraphFrameMenu()

    utilityMenu = getMenuBarAndDispaly_0(MenuBar, "Utilities")


    root.config(menu=MenuBar)
    mainloop()
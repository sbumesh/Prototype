import tkinter
from tkinter import *

from GuiUtilities.MenusAndPopupMenus import alertBox, subMenus_00, addMenusUsinglist, showPopup
from GuiUtilities.TextBoxUtility import textBoxTrigger

vSingleSelection = "Single Selection"
vmultiSelection= "Multi Selection"
vdelete = "Delete Selected"
vSortAll  = "Sort All"
vIndentAll = "Indent All"
vDeleteAll = "Delete All"

listpopup= [vSingleSelection , vmultiSelection , vdelete ,vDeleteAll ,vSortAll,vIndentAll]



def listBoxTrigger(label,*args) :
    mylistBox= args[0][0][0]
    print( mylistBox.curselection())
    if label == vSingleSelection  :
        mylistBox['selectmode'] = 'browse'
    elif label == vmultiSelection  :
        mylistBox['selectmode'] = EXTENDED
    elif label == vDeleteAll:
        mylistBox.delete(0, END)
    elif label == vdelete  :
        idx=mylistBox.curselection()
        print(len(idx))
        if len(idx) == 1   :
            mylistBox.delete( idx,idx )
        else  :
            pos = 0
            for i in idx:
                idx1 = int(i) - pos
                mylistBox.delete(idx1, idx1)
                pos = pos + 1

    elif label == vSortAll:
        myList= sorted(mylistBox.get(0,END) ,reverse=True)
        mylistBox.delete(0,END)
        for aitem in myList  :

            # self.list_box_1.insert( END,s )
            mylistBox.insert( END,aitem)
    else:
        alertBox("info", ' under Construction')
    return

def addPopupMenuFormListBox(listBox,root,MenuBar=None) :
    # if (str(type(listBox)) != "<class 'tkinter.Text'>" )  :
    #     alertBox("error" ,' Not a Valid TextBox to add popup')
    #     return
    if (MenuBar == None) :
           MenuBar = tkinter.Menu(root)


    childMenu1 = subMenus_00(parentMenu=MenuBar, root=root, label="ListBox Utilities")
    addMenusUsinglist(childMenu1, listpopup, listBoxTrigger,listBox)
    mypopup= showPopup(MenuBar, root, listBox)
    return childMenu1,mypopup


class ListBoxTest :
    def __init__(self  , root, *args) :
        myList = args[0]

        self.root = root
        # self.root = Tk()
        scrollbar = Scrollbar(root)
        # scrollbar.pack(side=RIGHT, fill=Y)
        self.list_box_1 = Listbox(self.root, selectmode=EXTENDED)
        self.list_box_1.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.list_box_1.yview)

        # self.list_box_1.bind("<Enter>", func= ListBoxEnter()  )
        # self.list_box_1.bind("<Leave>", func= ListBoxEnter()  )

        # self.list_box_1.pack()

        MenuBar = tkinter.Menu(self.root)
        # addMenusUsinglist(MenuBar)
        self.myMenuBAr, self.myPopupMenu = addPopupMenuFormListBox(self.list_box_1, self.root, MenuBar)
        self.captureMouseEnter(self.myMenuBAr)

        # for i in range(0, 10) :
        for aitem in myList:
            self.addItem(aitem)
        # self.addItem(s)
        # self.root.mainloop()

    def addItem(self,myString) :
        self.list_box_1.insert(END, myString)

    ###################################
    #####  Capture mouse event for te4xt box entered and levae based on that enable or disable popupmenu options
    ############################################
    def captureMouseEnter(self , myMenuBAr):



        def menuEnableOrDisable(  menuOptionName):
             try :
                myMenuBAr.entryconfig(menuOptionName, state=DISABLED)
             except  :
                return



        def textBoxEnter(event):
            menuEnableOrDisable(vIndentAll)
            idx = self.list_box_1.curselection()
            print( len(idx))

        self.list_box_1.bind('<<ListboxSelect>>', textBoxEnter)
        self.list_box_1.bind('<<Enter>>', textBoxEnter)
############################################
    def __getConfig(Key, map):
        # print(self.list_box_1.config().get(key)[4])
        return map.get(Key)[4]

    def toggleSelection(key='selectmode', self=NONE):
        print(self.list_box_1.config().get(key)[4])


    def DeleteSelection(self) :
        items = self.list_box_1.curselection()
        print(items)
        pos = 0
        for i in items :
            idx = int(i) - pos
            self.list_box_1.delete( idx,idx )
            pos = pos + 1

if __name__ == '__main__'  :
   root = Tk()
   lbt=ListBoxTest( root, [1,2,3,4,5,6,7,8,9.10,2,3,4,5,6,7,8,9.10,2,3,4,5,6,7,8,9.10]   ,  [1,2,3,4,5,6,7,8,9.10])
   # lbt.myMenuBAr.add_separator()
   # lbt.myMenuBAr.add_separator()
   lbt.list_box_1.pack()
   # additionalListpopup = [ "move to Numeric" , "move to Date Field, Move to string Field"]
   # lbt12 = ListBoxTest(root, [])
   #
   # addMenusUsinglist(lbt.myMenuBAr, additionalListpopup, newListBoxTrigger, lbt.list_box_1 ,lbt12.list_box_1)
   # lbt12.list_box_1.pack()
   root.mainloop()

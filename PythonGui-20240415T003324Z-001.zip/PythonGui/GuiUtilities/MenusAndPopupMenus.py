import ctypes
from tkinter import Menu, Tk, mainloop, Text, DISABLED

# from tkinter import *
from tkinter.ttk import Label

myFont = ("Times", 12)
def alertBox(title="alert", message="you have issues to be resolved"):
    return (ctypes.windll.user32.MessageBoxW(0, message, title, 1))


def getMenuLabel(label,obj=None):
    print("its ", label)
    alertBox(message="its " + label)


def alertMenuLabel(label="",obj=None):
    print("its ", label)
    alertBox(message="it is a " + label)


def addMenubar_1(label, MenuBar, function=getMenuLabel ,*args):
    MenuBar.add_command(label=label, underline=1 , font=myFont , command=lambda: function(label,args))




def addMenusUsinglist(myMenu, list=['one', 'two', 'three'], myFunction=getMenuLabel, *args):
    for aitem in list:
        # filemenu.add_command(label=aitem, command=lambda: print(aitem))
        addMenubar_1(aitem, myMenu, myFunction,args)

    return


def getMenuBarAndDispaly_0(MenuBar, Label):
    myMenu = Menu(MenuBar, tearoff=0, font=myFont)

    MenuBar.add_cascade(label=Label,  font=myFont ,   menu=myMenu)
    return myMenu


def subMenus_00(parentMenu, root, label="Sub Menu"):
    # fileMenu = Menu(root, tearoff=0)
    childMenu = Menu(root, tearoff=0)
    # childMenu.add_command(label="Replace Using Dialog Box  ",
    #                             command=lambda: getMenuLabel("Replace Using Dialog Box  "))
    FilesubPopup = parentMenu.add_cascade(label=label,  font=myFont , menu=childMenu)
    return childMenu


#################
###popup menu
##########
def showPopup(popupMenu, root, object):
    def do_popup(event):
        # display the popup menu
        try:
            popupMenu.tk_popup(event.x_root, event.y_root, 0)
        finally:
            # make sure to release the grab (Tk 8.0a1 only)
            popupMenu.grab_release()

    object.bind("<Button-3>", do_popup)
    return popupMenu


#############################
####Testing
##############################3
def testTextBox()  :
    root = Tk()
    myText = Text(root, text="Hello, world!")
    myText.pack()
    mainloop()
    return
def testMenuBar()  :
    root = Tk()
    MenuBar = Menu(root)
    myMenu = getMenuBarAndDispaly_0(MenuBar, "File")
    myMenu = getMenuBarAndDispaly_0(MenuBar, "Edit")
    myMenu = getMenuBarAndDispaly_0(MenuBar, "Tool")
    myMenu = getMenuBarAndDispaly_0(MenuBar, "View")
    root.config(menu=MenuBar)
    mainloop()

def testmenu():
    root = Tk()
    myLabel = Label(root, text="Hello, world!")
    MenuBar = Menu(root)
    myMenu = getMenuBarAndDispaly_0(MenuBar, "File")
    # fileMenu = Menu(MenuBar, tearoff=0)
    # MenuBar.add_cascade(label="File", menu=fileMenu)
    addMenusUsinglist(myMenu)
    # addMenubar_1("hello", myMenu)

    childMenu1 = subMenus_00(parentMenu=myMenu, root=root, label="Sub menu1")
    addMenusUsinglist(childMenu1)

    childMenu2 = subMenus_00(parentMenu=childMenu1, root=root, label="Sub menu2")
    addMenusUsinglist(childMenu2)

    childMenu3 = subMenus_00(parentMenu=myMenu, root=root, label="Sub menu3")
    addMenusUsinglist(childMenu2)

    EditMenu = getMenuBarAndDispaly_0(MenuBar, "Edit")
    addMenusUsinglist(EditMenu)
    # addMenubar_1("Edit Hello", EditMenu)
    # subMenus_00(EditMenu, root)
    # showPopup(popupMenu, root, object)

    showPopup(myMenu, root, myLabel)
    myLabel.pack()

    root.config(menu=MenuBar)
    mainloop()
    return


def testPopup(myWidget,root):
    # root = Tk()
    # myLabel = Label(root, text="Hello, world!")
    popup = Menu(root, tearoff=0)
    popup.add_separator()
    popup.add_separator()

    # myWidget.pack()
    showPopup(popup, root, myWidget)
    # mainloop()

def diableMenus(MenuBar,menuNumber=2)  :
    MenuBar.entryconfig(menuNumber, state=DISABLED)

def testmenulist():
    root = Tk()
    mylist = ['new Porject', 'New']
    MenuBar, fileMenu   = addMenusUsinglist("file", root, mylist, alertMenuLabel)
    MenuBar1, fileMenu2 = addMenusUsinglist("Edit", root, mylist, alertMenuLabel)
    subMenus_00(fileMenu, root)
    root.config(menu=MenuBar1)
    mainloop()
    return


if __name__ == "__main__":

    testmenu()
    # testmenulist()
    # testMenuBar()
    # testPopup()

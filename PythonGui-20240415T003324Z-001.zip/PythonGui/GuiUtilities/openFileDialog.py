from tkinter.filedialog import askopenfilename


def openFileDialog(     initialdir  =    "../Testing",
                        title       =        "choose your file",
                        list=[
                               ("CSV File", "*.csv") ,
                               ("XML File", "*.xml"),
                               ("JSON File", "*.json"),
                               ("All files", "*.*")
                            ]
                  ):

    fileName = askopenfilename(initialdir=initialdir,
                               title=title,
                               filetypes=list
                               )
    return fileName

if __name__ == '__main__' :
    openFileDialog()
import tkinter as tk
from tkinter import W


def myShowMyChoice(self,v ,*argc):
    # language = self.languages
    print(v.get(), self.languages[v.get()][0])
    self.selected= self.languages[v.get()][0]

class myRadioButton  :
  # def ShowMyChoice(self,v):
  #       language =  self.languages
  #       print(v.get(), language[v.get()][0])

  def __init__(self,mylanguage,myrow=0,mycol=0,funcname=myShowMyChoice,root =None,*argc):
    # root = tk.Tk()
    self.languages = mylanguage
    self.selected=None
    v = tk.IntVar()
    v.set(0)  # initializing the choice, i.e. Python

    # tk.Label(root,
    # text = """Choose your favourite programming language:""",
    # justify = tk.LEFT,
    # padx = 20).pack()

    for val, language in enumerate(self.languages):

          tk.Radiobutton(root,
                         text = language[0],
                         padx = 20,
                         variable = v,
                         bd=2,
                         # relief = tk.SUNKEN,
                         # indicatoron =0,
                         # bgground= 'blue',
                         command = lambda: funcname( self, v ,*argc),
                         value = val).grid(row=myrow,column=mycol,stick='w',columnspan =1)
          myrow  =myrow+1
          # mycol = mycol + 1

    # root.mainloop()

if __name__ == '__main__'  :
    languages = [
     ("Python", 1),
    ("Perl", 2),
    ("Java", 3),
    ("C++", 4),
    ("C", 5)
    ]
    root = tk.Tk()
    # nyFrame= tk.Frame()
    myCombox1 = myRadioButton(languages, 0, 0,myShowMyChoice,root)
    # nyFrame.pack(side= tk.LEFT, anchor=W)
    root.mainloop()
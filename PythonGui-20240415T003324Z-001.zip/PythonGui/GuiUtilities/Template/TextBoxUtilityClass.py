import tkinter
from tkinter import END, RIGHT, INSERT, LEFT, BOTH, HORIZONTAL, Y, DISABLED, RAISED, NORMAL

from GuiUtilities.MenusAndPopupMenus import alertBox, addMenusUsinglist, showPopup, subMenus_00, getMenuBarAndDispaly_0


vCopySelected = "Copy Selected"
vCopyAll= "Copy All"
vPaste = "Paste"
vClearAll  = "Clear All"
vIndentAll = "Indent All"

listpopup= [vCopySelected , vCopyAll , vPaste  ,vClearAll,vIndentAll]

####################
####Text box utils
#######################33
def __gettextArea12GetConfig(Key, map):
    # print(text.config().get(key)[4])
    return map.get(Key)[4]


def TextBoxGetAll(myTextBox)  :
    text = myTextBox.get("1.0", tkinter.END)
    myTextBox.clipboard_append(text)
    # alertBox(message="its " + text)
    return text

def TextBoxClear(myTextBox)  :
    myTextBox.delete(1.0, END)
    return myTextBox


def TextBoxSelectedText(myTextBox)  :
    text=""
    try:
        text=myTextBox.get('sel.first', 'sel.last')
        myTextBox.clipboard_append(text)
    except  :
         text = ""
    return text

def TextBoxPaste(myTextBox )  :
    TextBoxClear(myTextBox)
    myTextBox.insert(tkinter.INSERT, myTextBox.clipboard_get())
    return myTextBox
def appendTextBoxPaste(myTextBox,myString )  :
    TextBoxClear(myTextBox)
    myTextBox.insert(tkinter.INSERT, myString)
    return myTextBox
####################
####Text box popup trigger
#######################33
def textBoxTrigger(label,*args) :
    myTextBox= args[0][0][0]
    if (str(type(myTextBox)) != "<class 'tkinter.Text'>" )  :
        alertBox("error" ,' Not a Valid TextBox')
        return
    if (label == vCopySelected)  :
        try :
           alertBox( vCopySelected ,TextBoxSelectedText(myTextBox) )
        except  :
            return ""
    elif  (label == vCopyAll)  :
         text = TextBoxGetAll(myTextBox)
         alertBox(vCopyAll, text)
         return text
    elif  (label == vPaste)  :
         TextBoxPaste(myTextBox)
    elif  (label == vClearAll)  :
         TextBoxClear(myTextBox)
    elif (label == vIndentAll):
        text = TextBoxGetAll(myTextBox)
    return


####################
#### Attach popup to text box
#######################33
def addPopupMenuFormTextBox(textBox,root,MenuBar=None) :
    if (str(type(textBox)) != "<class 'tkinter.Text'>" )  :
        alertBox("error" ,' Not a Valid TextBox to add popup')
        return
    if (MenuBar == None) :
           MenuBar = tkinter.Menu(root)


    childMenu1 = subMenus_00(parentMenu=MenuBar, root=root, label="TextBox Utilities")
    addMenusUsinglist(childMenu1, listpopup, textBoxTrigger,textBox)
    mypopup= showPopup(MenuBar, root, textBox)
    return childMenu1,mypopup
###################################
#####  Capture mouse event for te4xt box entered and levae based on that enable or disable popupmenu options
############################################
def captureMouseEnter(myTextBox,myMenuBAr)  :

    def menuEnableOrDisable(myText,menuOptionName)  :
        if (myText=="") :
                myMenuBAr.entryconfig(menuOptionName, state=DISABLED)
        else  :
                myMenuBAr.entryconfig(menuOptionName, state=NORMAL)
        return

    def textBoxEnter(self, event=None):
        menuEnableOrDisable(TextBoxSelectedText(myTextBox)  , vCopySelected)
        menuEnableOrDisable(TextBoxGetAll(myTextBox).replace("\n",""), vCopyAll)
        menuEnableOrDisable(myTextBox.clipboard_get().replace("\n", ""), vPaste)
        return

    myTextBox.bind("<Enter>", textBoxEnter)
    myTextBox.bind("<Leave>", textBoxEnter)
    return


####################
####  Crerate Text box  call to attach popup scrollbar 3) mouse events
#######################33
def gettextArea12(root, test="hi"):  ## tested
    xscrollbar = tkinter.Scrollbar(root, orient=HORIZONTAL)
    # xscrollbar.pack(side=tkinter.BOTTOM, fill=tkinter.X)
    yscrollbar = tkinter.Scrollbar(root)
    # yscrollbar.pack(side=RIGHT, fill=Y)
    myText = tkinter.Text(root,
                        # height=180,
                        # width=180,
                        xscrollcommand=xscrollbar.set,
                        yscrollcommand=yscrollbar.set, undo=True, wrap="word"
                        )
    myText.insert(INSERT, test)
    myText.insert(END, "\n\n")
    # myText.grid(row=0,col=0)
    xscrollbar.config(command=myText.xview)
    yscrollbar.config(command=myText.yview)

    ############################# popup menu defination
    MenuBar = tkinter.Menu(root)
    # addMenusUsinglist(MenuBar)
    myMenuBAr, myPopupMenu = addPopupMenuFormTextBox(myText, root, MenuBar)

    # addMenusUsinglist(MenuBar)

    # myMenuBAr.entryconfig("Paste", state=DISABLED)
    ############################# popup menu defination end
    captureMouseEnter(myText,myMenuBAr)

    # myText.grid(row=0, col=0)


    return myText,MenuBar,



if __name__ == "__main__":
    root = tkinter.Tk()
    win= tkinter.Frame()
    win.grid(row=0)
    win1 = tkinter.Frame()
    win1.grid(row=5)
    myText,myMenubar = gettextArea12(root)
    myMenubar.add_separator()

    myText.grid(row=0)

    tkinter.mainloop()
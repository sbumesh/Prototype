from tkinter import Tk, mainloop, Button, Label, Entry, Frame, SUNKEN, END

from GuiUtilities.Template.RadioButtonClass import myRadioButton
from GuiUtilities.Template.TextBoxUtilityClass import gettextArea12
from GuiUtilities.Template.openFileForPandas import openFileForPAndaProcessing
from GuiUtilities.openFileDialog import openFileDialog


def callback(event)  :
    print('hi')
    myopenfile = openFileForPAndaProcessing()


LARGE_FONT = ("ariel", 20)
rowmax=50
columnMax=40
leftSpace=1
rightSpace=columnMax -3
def addgrids(root):
    for i in range(columnMax):
        root.columnconfigure(i, weight = 1)
    for i in range(rowmax):
        root.rowconfigure(i, weight = 1)
    return root
def myShowMyChoice(self,v ,*argc):
    # language = self.languages
    rootself= argc[0]
    selected = self.languages[v.get()][0]
    print(selected, self.languages[v.get()][0])
    if (selected == 'File') :
       # rootself.filebutton.config(state='normal')
       if(rootself.fileEntry.get() =="")  :
          text= openFileDialog()
          print("file name" , text)
          rootself.fileEntry.delete(0,END)
          rootself.fileEntry.insert(0, text)
    # else  :
    #    rootself.filebutton.config(state = 'disabled')

    rootself.selected= selected

class openFilePRocessingTemplate() :
  def __init__(self,root):
    # root = Tk()
    addgrids(root)
    ### Title
    Label(root, text = "Panda Excel Utility" ,font=LARGE_FONT ).grid(row = 0, sticky = 'w',column = 5  )


    ### TextBox and Command Line
    myText,myMenubar = gettextArea12(root)
    root.geometry("1399x880")
    # Label(root, text = 'Open File For Panda Processing', font = LARGE_FONT).grid(row = 0, column = 7)

    Label(root, text = 'File Name \n /URL').grid(row = 2, column = leftSpace)
    fileEntry = Entry(root, width = 100)
    self.fileEntry = fileEntry
    myText.grid(row = 15, sticky = 'nswe',column = leftSpace,columnspan = columnMax -4,rowspan=28)
    fileEntry.grid(row = 2, stick = 'we', column = leftSpace + 2, columnspan = 10, rowspan = 1)
    nyFrame = Frame(root, width = 100, bd = 2, highlightthickness = 1, relief = SUNKEN)
    FileTypechoices = [
              ("File", 1),
              ("URL", 2)
          ]
    myRadioButton(FileTypechoices, 0, 0, myShowMyChoice, nyFrame,self)
    nyFrame.grid(row = 2, column = leftSpace + 13, rowspan = 2, columnspan = 2,stick ='w')


    # openButton = Button(root, text = "Open CSV File")
    # openButton.grid(row = 15, sticky = 'nswe',column = columnMax-2,columnspan = 1,rowspan=1)
    # openButton.bind("<Button-1>", callback)

    processButton= Button(root, text = "Process File")
    processButton.grid(row = 20, sticky = 'nswe', column = columnMax - 2, columnspan = 1, rowspan = 1)
    self.processButton=processButton
    Button(root, text = "Exit").grid(row = 22, sticky = 'nswe',column = columnMax-2,columnspan = 1,rowspan=1)


if __name__ == "__main__" :
    root = Tk()
    mytempalte= openFilePRocessingTemplate(root)
    mytempalte.processButton.bind("<Button-1>", callback)
    mainloop()
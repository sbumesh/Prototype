from tkinter import Tk, mainloop, Entry, Button, Menu, Frame, SUNKEN, DISABLED, END
from tkinter.ttk import Label

from GuiUtilities.MenusAndPopupMenus import showPopup, getMenuBarAndDispaly_0, testPopup, addMenusUsinglist
from GuiUtilities.Template.RadioButtonClass import myRadioButton, myShowMyChoice
from GuiUtilities.openFileDialog import openFileDialog


# def myShowMyChoice(self,v ,*argc):
#     # language = self.languages
#     rootself= argc[0]
#     selected = self.languages[v.get()][0]
#     print(selected, self.languages[v.get()][0])
#     if (selected == 'File') :
#        # rootself.filebutton.config(state='normal')
#        if(rootself.fileEntry.get() =="")  :
#           text= openFileDialog()
#           print("file name" , text)
#           rootself.fileEntry.delete(0,END)
#           rootself.fileEntry.insert(0, text)
#     # else  :
#     #    rootself.filebutton.config(state = 'disabled')
#
#     rootself.selected= selected




LARGE_FONT = ("ariel", 20)
rowmax=50
columnMax=40
leftSpace=1
rightSpace=columnMax -3
def addgrids(root):
    for i in range(columnMax):
        root.columnconfigure(i, weight = 1)
    for i in range(rowmax):
        root.rowconfigure(i, weight = 1)
    return root
class openFileForPAndaProcessing() :
      def __init__(self):
          root = Tk()
          root= addgrids(root)
          Label(root, text='Open File For Panda Processing',font = LARGE_FONT ).grid(row= 0, column=7)
          Label(root, text = 'File Name \n /URL' ).grid(row = 2,   column = leftSpace )
          fileEntry=Entry(root, width = 100 )
          self.fileEntry = fileEntry

          # filebutton =Button(root, text = "Open File \nDialog",state='disabled',command= openmyFileDialog())
          # filebutton.grid(row = 2, column = leftSpace + 12, columnspan = 1,
          #                                           rowspan = 1)
          #
          # self.filebutton =filebutton
          MenuBar = Menu(root)
          myMenu = getMenuBarAndDispaly_0(MenuBar, "File")
          fileTypeLinklist=['File','URL', 'Clip Board']

          addMenusUsinglist(myMenu,fileTypeLinklist)
          showPopup(myMenu, root, fileEntry)
          fileEntry.grid(row = 2, stick = 'we', column = leftSpace + 2, columnspan = 10, rowspan = 1)
          ### radiobutton
          nyFrame = Frame(root, width = 100, bd = 2, highlightthickness = 1, relief = SUNKEN)
          FileTypechoices = [
              ("File", 1),
              ("URL", 2),
              ("Clip Board", 3)
          ]
          myRadioButton(FileTypechoices, 0, 0, myShowMyChoice, nyFrame,self )
          nyFrame.grid(row = 2, column = leftSpace + 13, rowspan = 2, columnspan = 2,stick ='w')
          ### end radiobutton

          root.geometry("1000x160")
          # mainloop()
if __name__ == "__main__":
    myopenfile=openFileForPAndaProcessing()